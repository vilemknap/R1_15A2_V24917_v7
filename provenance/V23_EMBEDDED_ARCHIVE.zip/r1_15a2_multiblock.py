# -*- coding: utf-8 -*-
"""Pure multi-block design logic for R1 STEP 15A2 V2.1.

This module has no Visum COM dependency.  It converts actual-path P/A guidance
into bounded generation-parameter candidates and converts fresh 11D component
curve diagnostics into bounded component-specific b/c candidates.

Important contracts
-------------------
* No OD matrix is written here.
* A backtracking scale is applied exactly once to an unscaled proposal.
* LONG component b/c calibration is enabled only when an explicit per-component
  100-200 km target authority exists.  An aggregate NATIVE_CL target is a guard,
  not a component target.
* SCHOOL is supported, but follows the configured authority policy.  AUTO means
  that 11D must report ACTIVE_COMPONENT_DIST_TARGET.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

EPS = 1.0e-12


def sval(value: Any, default: str = "") -> str:
    if value is None:
        return default
    try:
        return str(value)
    except Exception:
        return default


def fval(value: Any, default: Optional[float] = None) -> Optional[float]:
    if value is None:
        return default
    try:
        if isinstance(value, str):
            text = value.strip().replace("\ufeff", "").replace("\u00a0", "").replace(" ", "").replace(",", ".")
            if not text or text.lower() in ("nan", "none", "null"):
                return default
            value = text
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def ival(value: Any, default: Optional[int] = None) -> Optional[int]:
    out = fval(value, None)
    if out is None:
        return default
    try:
        return int(round(out))
    except Exception:
        return default


def clamp(value: float, low: float, high: float) -> float:
    return min(float(high), max(float(low), float(value)))


COMPONENT_REGISTRY: Dict[str, Dict[str, Any]] = {
    "WORK_E_C": {"family": "WORK", "dstrat_code": "1_WORK_E_C", "matrix_no": 9101},
    "WORK_E_noC": {"family": "WORK", "dstrat_code": "1_WORK_E_noC", "matrix_no": 9102},
    "WORK_noE_C": {"family": "WORK", "dstrat_code": "1_WORK_noE_C", "matrix_no": 9103},
    "WORK_noE_noC": {"family": "WORK", "dstrat_code": "1_WORK_noE_noC", "matrix_no": 9104},
    "WORK_stud": {"family": "WORK", "dstrat_code": "1_WORK_stud", "matrix_no": 9105},
    "SERV_E_C": {"family": "SERVICE", "dstrat_code": "2_SERV_E_C", "matrix_no": 9106},
    "SERV_E_noC": {"family": "SERVICE", "dstrat_code": "2_SERV_E_noC", "matrix_no": 9107},
    "SERV_noE_C": {"family": "SERVICE", "dstrat_code": "2_SERV_noE_C", "matrix_no": 9108},
    "SERV_noE_noC": {"family": "SERVICE", "dstrat_code": "2_SERV_noE_noC", "matrix_no": 9109},
    "SERV_stud": {"family": "SERVICE", "dstrat_code": "2_SERV_stud", "matrix_no": 9110},
    "LONG_E_C": {"family": "LONG", "dstrat_code": "3_LONG_E_C", "matrix_no": 9111},
    "LONG_E_noC": {"family": "LONG", "dstrat_code": "3_LONG_E_noC", "matrix_no": 9112},
    "LONG_noE_C": {"family": "LONG", "dstrat_code": "3_LONG_noE_C", "matrix_no": 9113},
    "LONG_noE_noC": {"family": "LONG", "dstrat_code": "3_LONG_noE_noC", "matrix_no": 9114},
    "LONG_stud": {"family": "LONG", "dstrat_code": "3_LONG_stud", "matrix_no": 9115},
    "SCHOOL": {"family": "SCHOOL", "dstrat_code": "5_SCHOOL", "matrix_no": 9117},
}

GENERATION_ATTRS = [
    "ADD_PROD_W", "ADD_ATT_W", "ADD_SALARY", "ADD_PROD_S", "ADD_ATT_S",
    "ZAHR_PROD_WORK", "ZAHR_ATR_WORK", "ZAHR_PROD_SERV", "ZAHR_ATR_SERV",
]

GENERATION_ATTR_MAP = {
    ("WORK", "PROD", "DOMESTIC"): "ADD_PROD_W",
    ("WORK", "ATT", "DOMESTIC"): "ADD_ATT_W",
    ("SERVICE", "PROD", "DOMESTIC"): "ADD_PROD_S",
    ("SERVICE", "ATT", "DOMESTIC"): "ADD_ATT_S",
    ("WORK", "PROD", "ZAHR"): "ZAHR_PROD_WORK",
    ("WORK", "ATT", "ZAHR"): "ZAHR_ATR_WORK",
    ("SERVICE", "PROD", "ZAHR"): "ZAHR_PROD_SERV",
    ("SERVICE", "ATT", "ZAHR"): "ZAHR_ATR_SERV",
}


def _row_map(rows: Sequence[Mapping[str, Any]], key: str) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for row in rows or []:
        name = sval(row.get(key, "")).strip()
        if name:
            out[name] = dict(row)
    return out


def _bin_key(low: Any, high: Any, label: Any = "") -> str:
    lo = fval(low, None); hi = fval(high, None)
    if lo is not None and hi is not None:
        return "%.6f|%.6f" % (float(lo), float(hi))
    return sval(label).strip()


def _normalized_target_bins(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, float]]:
    out = []
    total = 0.0
    for row in rows or []:
        lo = fval(row.get("bin_low"), None); hi = fval(row.get("bin_high"), None)
        sh = max(0.0, fval(row.get("target_share"), 0.0) or 0.0)
        if lo is None or hi is None:
            continue
        out.append({"bin_low": float(lo), "bin_high": float(hi), "target_share": sh})
        total += sh
    if total <= EPS:
        return []
    for row in out:
        row["target_share"] /= total
    return out


def _component_policy(component: str, family: str, cfg: Mapping[str, Any], target_status: str) -> Tuple[bool, str]:
    td_cfg = cfg.get("td", {})
    policies = td_cfg.get("component_policy", {}) or {}
    mode = sval(policies.get(component, policies.get(family, "AUTO"))).strip().upper()
    if mode in ("OFF", "DISABLED", "FROZEN", "REPORT_ONLY"):
        return False, "POLICY_%s" % mode
    if family == "LONG":
        # LONG requires explicit component authority; aggregate CL authority is not enough.
        if mode not in ("CALIBRATE", "ON", "ENABLED", "AUTO"):
            return False, "LONG_POLICY_%s" % mode
        return True, "LONG_COMPONENT_AUTHORITY_REQUIRED"
    if family == "SCHOOL" and mode == "AUTO":
        return ("ACTIVE_COMPONENT_DIST_TARGET" in target_status.upper(), "SCHOOL_AUTO_REQUIRES_ACTIVE_TARGET")
    if mode == "AUTO":
        return ("ACTIVE_COMPONENT_DIST_TARGET" in target_status.upper(), "AUTO_REQUIRES_ACTIVE_TARGET")
    return mode in ("CALIBRATE", "ON", "ENABLED"), "EXPLICIT_%s" % mode


def _signal_from_bins(component: str, family: str, matrix_no: int, dstrat_code: str,
                      summary: Mapping[str, Any], model_bins: Sequence[Mapping[str, Any]],
                      target_bins: Sequence[Mapping[str, Any]], authority_id: str,
                      authority_status: str, cfg: Mapping[str, Any]) -> Dict[str, Any]:
    tmap = {_bin_key(r.get("bin_low"), r.get("bin_high"), r.get("bin_label")): r for r in target_bins}
    detail = []
    abs_sum = sq_sum = 0.0
    model_mean_num = model_den = 0.0
    target_mean_num = target_den = 0.0
    short_excess = mid_deficit = tail_excess = 0.0
    short_signed = mid_signed = tail_signed = 0.0
    for row in model_bins:
        lo = fval(row.get("bin_low"), None); hi = fval(row.get("bin_high"), None)
        if lo is None or hi is None:
            continue
        key = _bin_key(lo, hi, row.get("bin_label"))
        model = max(0.0, fval(row.get("share_conditioned"), 0.0) or 0.0)
        target = max(0.0, fval((tmap.get(key) or {}).get("target_share"), 0.0) or 0.0)
        diff = model - target
        mid = 0.5 * (float(lo) + float(hi))
        abs_sum += abs(diff); sq_sum += diff * diff
        model_mean_num += mid * model; model_den += model
        target_mean_num += mid * target; target_den += target
        if family != "LONG":
            if float(lo) < 1.0 + 1.0e-9:
                short_excess += max(0.0, diff)
                short_signed += diff
            if float(lo) >= 1.0 - 1.0e-9 and float(hi) <= 15.0 + 1.0e-9:
                mid_deficit += max(0.0, -diff)
                mid_signed += diff
            if float(lo) >= 25.0 - 1.0e-9:
                tail_excess += max(0.0, diff)
                tail_signed += diff
        else:
            if float(lo) < 120.0 + 1.0e-9:
                short_excess += max(0.0, diff)
                short_signed += diff
            if float(lo) >= 120.0 - 1.0e-9 and float(hi) <= 150.0 + 1.0e-9:
                mid_deficit += max(0.0, -diff)
                mid_signed += diff
            if float(lo) >= 150.0 - 1.0e-9:
                tail_excess += max(0.0, diff)
                tail_signed += diff
        detail.append({
            "bin_low": float(lo), "bin_high": float(hi), "model_share": model,
            "target_share": target, "share_diff_model_minus_target": diff,
        })
    model_keys = {_bin_key(r.get("bin_low"), r.get("bin_high"), r.get("bin_label")) for r in model_bins}
    target_keys = set(tmap)
    missing_target_bins = sorted(target_keys - model_keys)
    missing_model_targets = sorted(model_keys - target_keys)
    target_coverage = sum(max(0.0, fval((tmap.get(k) or {}).get("target_share"), 0.0) or 0.0) for k in (target_keys & model_keys))
    authority_complete = bool(target_keys and not missing_target_bins and not missing_model_targets and target_coverage >= 1.0 - 1.0e-6)
    model_mean = model_mean_num / model_den if model_den > EPS else fval(summary.get("mean_model_conditioned"), None)
    target_mean = target_mean_num / target_den if target_den > EPS else fval(summary.get("mean_target"), None)
    l1 = 0.5 * abs_sum
    rmse = math.sqrt(sq_sum / max(1, len(detail))) if detail else float("inf")
    mean_delta = (model_mean - target_mean) if model_mean is not None and target_mean is not None else None
    target_status = sval(summary.get("target_status", authority_status))
    allowed, policy_reason = _component_policy(component, family, cfg, target_status)
    calibratable = bool(allowed and detail and target_den > EPS and authority_complete)
    if allowed and not authority_complete:
        policy_reason = "INCOMPLETE_OR_MISMATCHED_BIN_AUTHORITY"
    return {
        "component": component,
        "family": family,
        "matrix_no": matrix_no,
        "dstrat_code": dstrat_code,
        "target_status": target_status,
        "authority_status": authority_status,
        "authority_id": authority_id,
        "policy_reason": policy_reason,
        "calibratable": calibratable,
        "conditioned_volume": fval(summary.get("conditioned_volume"), 0.0) or 0.0,
        "total_volume": fval(summary.get("total_volume"), 0.0) or 0.0,
        "mean_model": model_mean,
        "mean_target": target_mean,
        "mean_delta": mean_delta,
        "l1_half": l1,
        "rmse_share": rmse,
        "short_excess": short_excess,
        "mid_deficit": mid_deficit,
        "tail_excess": tail_excess,
        "short_signed": short_signed,
        "mid_signed": mid_signed,
        "tail_signed": tail_signed,
        "authority_complete": authority_complete,
        "target_bin_coverage": target_coverage,
        "missing_target_bins": missing_target_bins,
        "missing_model_targets": missing_model_targets,
        "model_bins": detail,
        "objective": l1 + 0.5 * (abs(mean_delta) / max(EPS, target_mean) if mean_delta is not None and target_mean else 0.0) + 0.25 * rmse,
    }


def build_td_signals(summary_rows: Sequence[Mapping[str, Any]],
                     compare_rows: Sequence[Mapping[str, Any]],
                     baseline_rows: Sequence[Mapping[str, Any]],
                     long_authority: Optional[Mapping[str, Any]] = None,
                     config: Optional[Mapping[str, Any]] = None) -> Dict[str, Dict[str, Any]]:
    """Build component signals from fresh 11D output and explicit authorities."""
    cfg = config or {}
    smap = _row_map(summary_rows, "component")
    model_by_comp: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    target_by_comp: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in baseline_rows or []:
        comp = sval(row.get("component", "")).strip()
        if comp:
            model_by_comp[comp].append(dict(row))
    for row in compare_rows or []:
        comp = sval(row.get("component", "")).strip()
        if comp:
            target_by_comp[comp].append(dict(row))

    long_auth = dict(long_authority or {})
    long_components = long_auth.get("component_targets", {}) or {}
    signals: Dict[str, Dict[str, Any]] = {}
    for comp, reg in COMPONENT_REGISTRY.items():
        summary = smap.get(comp, {})
        family = reg["family"]
        model_bins = model_by_comp.get(comp, [])
        if family == "LONG":
            auth = long_components.get(comp)
            if not auth:
                signals[comp] = {
                    "component": comp, "family": family, "matrix_no": reg["matrix_no"],
                    "dstrat_code": reg["dstrat_code"], "target_status": sval(summary.get("target_status", "")),
                    "authority_status": "NO_COMPONENT_LONG_AUTHORITY",
                    "authority_id": sval(long_auth.get("authority_id", "")),
                    "policy_reason": "AGGREGATE_CL_TARGET_IS_GUARD_ONLY",
                    "calibratable": False,
                    "conditioned_volume": fval(summary.get("conditioned_volume"), 0.0) or 0.0,
                    "total_volume": fval(summary.get("total_volume"), 0.0) or 0.0,
                    "mean_model": fval(summary.get("mean_model_conditioned"), None),
                    "mean_target": None, "mean_delta": None,
                    "l1_half": None, "rmse_share": None, "short_excess": 0.0,
                    "mid_deficit": 0.0, "tail_excess": 0.0, "model_bins": [],
                    "objective": float("inf"),
                }
                continue
            target_bins = _normalized_target_bins(auth.get("bins", []))
            signals[comp] = _signal_from_bins(
                comp, family, reg["matrix_no"], reg["dstrat_code"], summary,
                model_bins, target_bins, sval(long_auth.get("authority_id", "LONG_COMPONENT_AUTHORITY")),
                sval(auth.get("status", "ACTIVE_LONG_COMPONENT_TARGET")), cfg,
            )
            continue
        signals[comp] = _signal_from_bins(
            comp, family, reg["matrix_no"], reg["dstrat_code"], summary,
            model_bins, target_by_comp.get(comp, []),
            "11D_ACTIVE_COMPONENT_DIST_TARGET", sval(summary.get("target_status", "")), cfg,
        )
    return signals


def _family_min_volume(family: str, td_cfg: Mapping[str, Any]) -> float:
    if family == "LONG":
        return float(td_cfg.get("long_min_conditioned_volume", 80.0))
    if family == "SCHOOL":
        return float(td_cfg.get("school_min_conditioned_volume", 500.0))
    return float(td_cfg.get("min_conditioned_volume", 1000.0))


def design_td_candidates(signals: Mapping[str, Mapping[str, Any]],
                         current_parameters: Mapping[str, Mapping[str, Any]],
                         family: str, cfg: Mapping[str, Any], scale: float = 1.0) -> Dict[str, Any]:
    """Create bounded component-specific b/c proposals.

    The unscaled trust-region delta is computed once.  ``scale`` is applied once
    at materialization, preventing the historical double-backtracking bug.
    """
    td_cfg = cfg.get("td", {})
    family_u = sval(family).upper().replace("SERV", "SERVICE")
    scale = clamp(float(scale), 0.0, 1.0)
    candidates: List[Dict[str, Any]] = []
    skipped: List[Dict[str, Any]] = []
    ranked: List[Tuple[float, str, Dict[str, Any]]] = []
    for comp, sig0 in signals.items():
        sig = dict(sig0)
        if sval(sig.get("family", "")).upper().replace("SERV", "SERVICE") != family_u:
            continue
        cur = current_parameters.get(comp)
        if not cur:
            skipped.append({"component": comp, "reason": "TD_PARAMETER_NOT_READ"}); continue
        if not bool(sig.get("calibratable", False)):
            skipped.append({"component": comp, "reason": sval(sig.get("authority_status", "NOT_CALIBRATABLE")), "policy_reason": sig.get("policy_reason", "")}); continue
        volume = float(sig.get("conditioned_volume", 0.0) or 0.0)
        if volume < _family_min_volume(family_u, td_cfg):
            skipped.append({"component": comp, "reason": "LOW_CONDITIONED_VOLUME", "conditioned_volume": volume}); continue
        b = fval(cur.get("current_b"), None); c = fval(cur.get("current_c"), None)
        if b is None or c is None:
            skipped.append({"component": comp, "reason": "B_OR_C_UNREADABLE"}); continue
        l1 = float(sig.get("l1_half", 0.0) or 0.0)
        mean_target = fval(sig.get("mean_target"), None); mean_delta = fval(sig.get("mean_delta"), 0.0) or 0.0
        mean_rel = mean_delta / max(EPS, abs(mean_target)) if mean_target not in (None, 0.0) else 0.0
        if l1 < float(td_cfg.get("min_l1_for_mutation", 0.06)) and abs(mean_rel) < float(td_cfg.get("mean_relative_deadband", 0.01)):
            skipped.append({"component": comp, "reason": "WITHIN_TD_DEADBAND", "l1_half": l1, "mean_relative_error": mean_rel}); continue
        short = float(sig.get("short_excess", 0.0) or 0.0)
        mid_deficit = float(sig.get("mid_deficit", 0.0) or 0.0)
        tail = float(sig.get("tail_excess", 0.0) or 0.0)
        short_signed = float(sig.get("short_signed", short) or 0.0)
        mid_signed = float(sig.get("mid_signed", -mid_deficit) or 0.0)
        tail_signed = float(sig.get("tail_signed", tail) or 0.0)
        # Positive b suppresses an excess of the shortest relations and refills
        # the middle. The signed form also allows b to decrease when the model
        # has too few shortest trips and too much middle-distance mass.
        shape_signal = short_signed - mid_signed
        raw_db = float(td_cfg.get("b_shape_gain", 0.40)) * shape_signal
        # More negative c shortens an overlong distribution; a tail deficit or
        # a too-short mean produces a positive delta (less negative c).
        raw_dc = (
            -float(td_cfg.get("c_mean_gain", 0.18)) * mean_rel
            -float(td_cfg.get("c_tail_gain", 0.12)) * tail_signed
            -float(td_cfg.get("c_b_compensation", 0.35)) * raw_db
        )
        if family_u == "LONG":
            raw_db *= float(td_cfg.get("long_b_gain_multiplier", 0.25))
            raw_dc *= float(td_cfg.get("long_c_gain_multiplier", 0.50))
            max_db = float(td_cfg.get("long_max_abs_b_delta", td_cfg.get("max_abs_b_delta", 0.08)))
            max_dc = float(td_cfg.get("long_max_abs_c_delta", td_cfg.get("max_abs_c_delta", 0.04)))
        else:
            max_db = float(td_cfg.get("max_abs_b_delta", 0.08))
            max_dc = float(td_cfg.get("max_abs_c_delta", 0.04))
        raw_db = clamp(raw_db, -max_db, max_db)
        raw_dc = clamp(raw_dc, -max_dc, max_dc)
        db = raw_db * scale
        dc = raw_dc * scale
        cand_b = clamp(float(b) + db, float(td_cfg.get("b_min", 0.0)), float(td_cfg.get("b_max", 5.0)))
        cand_c = clamp(float(c) + dc, float(td_cfg.get("c_min", -3.0)), float(td_cfg.get("c_max", 0.0)))
        priority = float(sig.get("objective", 0.0) or 0.0) * math.sqrt(max(1.0, volume))
        row = {
            "component": comp, "family": family_u, "dstrat_code": cur.get("dstrat_code", sig.get("dstrat_code", "")),
            "matrix_no": sig.get("matrix_no", ""), "authority_id": sig.get("authority_id", ""),
            "current_b": float(b), "current_c": float(c),
            "raw_delta_b": raw_db, "raw_delta_c": raw_dc,
            "backtracking_scale": scale, "delta_b": cand_b - float(b), "delta_c": cand_c - float(c),
            "candidate_b": cand_b, "candidate_c": cand_c,
            "conditioned_volume": volume, "l1_half": l1, "rmse_share": sig.get("rmse_share"),
            "mean_model": sig.get("mean_model"), "mean_target": mean_target,
            "mean_relative_error": mean_rel, "short_excess": short,
            "mid_deficit": mid_deficit, "tail_excess": tail,
            "short_signed": short_signed, "mid_signed": mid_signed,
            "tail_signed": tail_signed, "shape_signal": shape_signal,
            "priority": priority,
        }
        if abs(row["delta_b"]) <= 1.0e-12 and abs(row["delta_c"]) <= 1.0e-12:
            skipped.append({"component": comp, "reason": "CLAMPED_TO_NO_CHANGE"}); continue
        ranked.append((priority, comp, row))
    ranked.sort(key=lambda x: (-x[0], x[1]))
    max_components = max(1, int(td_cfg.get("max_components_per_block", 2)))
    candidates = [row for _, _, row in ranked[:max_components]]
    for _, comp, row in ranked[max_components:]:
        skipped.append({"component": comp, "reason": "DEFERRED_BY_COMPONENT_LIMIT", "priority": row["priority"]})
    return {
        "candidate_rows": candidates,
        "skipped_rows": skipped,
        "summary": {
            "family": family_u, "candidate_count": len(candidates), "skipped_count": len(skipped),
            "scale_applied_once": True, "backtracking_scale": scale,
            "selected_components": [r["component"] for r in candidates],
        },
    }


def td_component_metrics(signals: Mapping[str, Mapping[str, Any]], components: Sequence[str], cfg: Mapping[str, Any]) -> Dict[str, Any]:
    td_cfg = cfg.get("td", {})
    rows = []
    num = den = 0.0
    for comp in components:
        sig = signals.get(comp)
        if not sig or not bool(sig.get("calibratable", False)):
            continue
        l1 = float(sig.get("l1_half", 0.0) or 0.0)
        rmse = float(sig.get("rmse_share", 0.0) or 0.0)
        target = fval(sig.get("mean_target"), None); delta = fval(sig.get("mean_delta"), 0.0) or 0.0
        mean_rel = abs(delta) / max(EPS, abs(target)) if target not in (None, 0.0) else 0.0
        objective = (
            float(td_cfg.get("td_objective_l1_weight", 1.0)) * l1
            + float(td_cfg.get("td_objective_mean_weight", 0.5)) * mean_rel
            + float(td_cfg.get("td_objective_rmse_weight", 0.25)) * rmse
        )
        weight = math.sqrt(max(1.0, float(sig.get("conditioned_volume", 0.0) or 0.0)))
        num += weight * objective; den += weight
        rows.append({"component": comp, "objective": objective, "weight": weight, "l1_half": l1, "mean_relative_error": mean_rel, "rmse_share": rmse})
    return {"n": len(rows), "weighted_objective": num / den if den > EPS else float("inf"), "components": rows}


def _zone_lookup(zone_rows: Sequence[Mapping[str, Any]]) -> Dict[int, Dict[str, Any]]:
    out = {}
    for row in zone_rows or []:
        z = ival(row.get("zone_no"), None)
        if z is not None:
            out[int(z)] = dict(row)
    return out


def _eligible_zone(row: Mapping[str, Any], cfg: Mapping[str, Any]) -> Tuple[bool, str]:
    z = ival(row.get("zone_no"), None)
    excluded = set(int(x) for x in cfg.get("explicit_excluded_zone_nos", []) or [])
    excluded.update(int(x) for x in cfg.get("zahr", {}).get("explicit_excluded_zone_nos", []) or [])
    if z in excluded:
        return False, "EXPLICIT_EXCLUSION"
    return True, "OK"


def _salary_joint_design(work_rows: Sequence[Dict[str, Any]], zone_map: Mapping[int, Mapping[str, Any]],
                         cfg: Mapping[str, Any], scale: float) -> Tuple[Dict[int, float], Dict[int, float], Dict[str, Any]]:
    """Split WORK attraction log effects into ADD_ATT_W residual and salary basis.

    A single centred log-income coefficient is used.  This avoids a second free
    zone residual that would be non-identifiable with ADD_ATT_W.
    """
    salary_cfg = cfg.get("salary", {})
    if not salary_cfg.get("enabled", True) or not work_rows:
        return {}, {}, {"enabled": False, "status": "DISABLED_OR_EMPTY"}
    income_attr = sval(salary_cfg.get("income_attr", "AV_INCOME"))
    salary_attr = sval(salary_cfg.get("salary_attr", "ADD_SALARY"))
    offset = float(salary_cfg.get("formula_offset", 1000.0))
    denom = float(salary_cfg.get("formula_denominator", 2700.0))
    factor_floor = float(salary_cfg.get("factor_floor", 0.05))
    items = []
    logs = []
    for p in work_rows:
        z = int(p["zone_no"]); zr = zone_map.get(z, {})
        income = fval(zr.get(income_attr), None); salary = fval(zr.get(salary_attr), None)
        add_att_attr = sval(salary_cfg.get("work_attraction_attr", "ADD_ATT_W"))
        add_att = fval(zr.get(add_att_attr), None)
        if income is None or salary is None or add_att is None or income <= 0 or add_att <= EPS:
            continue
        g = 1.0 + (income * salary - offset) / denom
        if g <= factor_floor:
            continue
        logs.append(math.log(max(income, EPS)))
        items.append((z, float(p["requested_log_step"]), income, salary, g, float(p.get("base_margin_volume", 1.0) or 1.0)))
    if len(items) < int(salary_cfg.get("min_eligible_zones", 8)):
        return {}, {}, {"enabled": True, "status": "ADD_ATT_ONLY_FALLBACK", "eligible_zones": len(items)}
    mean_log = sum(logs) / len(logs)
    # Ridge coefficient for u ~= a + h*x*beta.  The ADD_ATT residual a is
    # penalised by zone_add_ridge; beta by basis_ridge.  Closed form after
    # eliminating a: a=(u-hx beta)/(1+lambda_a).
    lam_a = max(0.0, float(salary_cfg.get("zone_add_ridge_lambda", 1.0)))
    lam_b = max(0.0, float(salary_cfg.get("basis_ridge_lambda", 0.2)))
    num = den_beta = 0.0
    packed = []
    for z, u, income, salary, g, weight in items:
        x = math.log(max(income, EPS)) - mean_log
        h = income / (denom * g)
        hx = h * x
        w = max(1.0, weight)
        shrink = lam_a / (1.0 + lam_a) if lam_a > 0 else 0.0
        num += w * shrink * hx * u
        den_beta += w * shrink * hx * hx
        packed.append((z, u, income, salary, g, hx))
    beta = num / max(EPS, den_beta + lam_b)
    max_delta = float(salary_cfg.get("max_abs_delta_per_block", 0.04)) * scale
    salary_delta = {}
    add_att_residual = {}
    max_error = 0.0
    for z, u, income, salary, g, hx in packed:
        ds = clamp(beta * (math.log(max(income, EPS)) - mean_log), -max_delta, max_delta)
        salary_new = clamp(salary + ds, float(salary_cfg.get("salary_min", 0.0)), float(salary_cfg.get("salary_max", 3.0)))
        exact_salary_log = math.log(max(factor_floor, 1.0 + (income * salary_new - offset) / denom) / g)
        residual = u - exact_salary_log
        salary_delta[z] = salary_new - salary
        add_att_residual[z] = residual
        max_error = max(max_error, abs(residual + exact_salary_log - u))
    return salary_delta, add_att_residual, {
        "enabled": True, "status": "JOINT_RIDGE_OK", "eligible_zones": len(items),
        "beta": beta, "max_abs_effect_log_error": max_error,
    }


def design_generation_candidates(projection_rows: Sequence[Mapping[str, Any]],
                                 zone_rows: Sequence[Mapping[str, Any]], cfg: Mapping[str, Any],
                                 scale: float = 1.0) -> Dict[str, Any]:
    """Map balanced P/A guidance to bounded domestic, salary and ZAHR parameters.

    The input projection is already balanced in P/A space. Backtracking is
    applied once to its log steps. Candidate bounds and zero policies can make
    the implemented effect differ from the requested effect, so this routine
    recomputes the exact implemented log effect and reports P/A balance from
    that implemented effect rather than from unavailable/skipped rows.
    """
    scale = clamp(float(scale), 0.0, 1.0)
    zone_map = _zone_lookup(zone_rows)
    zcfg = cfg.get("zahr", {})
    threshold = float(zcfg.get("domestic_threshold", 0.5))
    domestic_mask = sval(zcfg.get("domestic_mask_attr", "NOT_ZAHR"))
    neighbour_attr = sval(zcfg.get("neighbour_attr", "ZAHR_SUSED"))
    population_attr = sval(zcfg.get("population_attr", "POP_ZP_2022"))
    attr_min = float(cfg.get("add_min", 0.0)); attr_max = float(cfg.get("add_max", 3.0))
    zahr_min = float(zcfg.get("min", 0.0)); zahr_max = float(zcfg.get("max", 10.0))
    preserve_zero_zahr = bool(zcfg.get("preserve_zero", True))
    preserve_zero_domestic = bool(cfg.get("preserve_zero_add", True))
    min_step = float(cfg.get("min_add_log_step", 5.0e-5))

    normalized: List[Dict[str, Any]] = []
    skipped: List[Dict[str, Any]] = []
    work_att_domestic: List[Dict[str, Any]] = []
    for p0 in projection_rows or []:
        p = dict(p0)
        z = ival(p.get("zone_no"), None)
        family = sval(p.get("family", "")).upper()
        role = sval(p.get("role", "")).upper()
        if z is None or family not in ("WORK", "SERVICE") or role not in ("PROD", "ATT"):
            skipped.append({"zone_no": z, "reason": "INVALID_PROJECTION_ROW"}); continue
        zr = zone_map.get(int(z))
        if not zr:
            skipped.append({"zone_no": z, "reason": "ZONE_NOT_FOUND"}); continue
        ok, reason = _eligible_zone(zr, cfg)
        if not ok:
            skipped.append({"zone_no": z, "family": family, "role": role, "reason": reason}); continue
        requested_log_step = float(fval(p.get("log_step"), 0.0) or 0.0) * scale
        if abs(requested_log_step) < min_step:
            continue
        is_domestic = float(fval(zr.get(domestic_mask), 0.0) or 0.0) >= threshold
        branch = "DOMESTIC" if is_domestic else "ZAHR"
        if branch == "ZAHR":
            # Exact TG border terms are multiplied by POP_ZP and ZAHR_SUSED.
            if float(fval(zr.get(neighbour_attr), 0.0) or 0.0) <= 0.0 or float(fval(zr.get(population_attr), 0.0) or 0.0) <= 0.0:
                skipped.append({"zone_no": z, "family": family, "role": role, "reason": "ZAHR_FORMULA_BASE_INACTIVE"}); continue
        attr = GENERATION_ATTR_MAP[(family, role, branch)]
        row = {
            "zone_no": int(z), "family": family, "role": role, "branch": branch, "attr": attr,
            "requested_log_step": requested_log_step,
            "base_margin_volume": float(fval(p.get("base_margin_volume"), 0.0) or 0.0),
            "guided_margin_delta": float(fval(p.get("guided_margin_delta"), 0.0) or 0.0) * scale,
            "projected_margin_delta": float(fval(p.get("projected_margin_delta"), 0.0) or 0.0) * scale,
        }
        normalized.append(row)
        if family == "WORK" and role == "ATT" and branch == "DOMESTIC":
            # Salary is identifiable only jointly with a positive ADD_ATT_W.
            add_att = fval(zr.get(sval(cfg.get("salary", {}).get("work_attraction_attr", "ADD_ATT_W"))), None)
            if add_att is not None and add_att > EPS:
                work_att_domestic.append(row)

    # requested_log_step is already backtracked; do not scale a second time.
    salary_delta, salary_residual, salary_summary = _salary_joint_design(work_att_domestic, zone_map, cfg, scale=1.0)
    salary_cfg = cfg.get("salary", {})
    salary_attr = sval(salary_cfg.get("salary_attr", "ADD_SALARY"))
    income_attr = sval(salary_cfg.get("income_attr", "AV_INCOME"))
    offset = float(salary_cfg.get("formula_offset", 1000.0))
    denom = float(salary_cfg.get("formula_denominator", 2700.0))
    factor_floor = float(salary_cfg.get("factor_floor", 0.05))

    # First materialize salary candidates so exact attraction effects are known.
    salary_candidates: Dict[int, Dict[str, Any]] = {}
    salary_log_effect: Dict[int, float] = {}
    for z, delta in salary_delta.items():
        zr = zone_map[z]
        current = fval(zr.get(salary_attr), None)
        income = fval(zr.get(income_attr), None)
        if current is None or income is None or income <= 0.0:
            skipped.append({"zone_no": z, "family": "WORK", "role": "ATT_SALARY", "reason": "SALARY_OR_INCOME_UNREADABLE"})
            continue
        proposed = clamp(float(current) + float(delta), float(salary_cfg.get("salary_min", 0.0)), float(salary_cfg.get("salary_max", 3.0)))
        old_factor = 1.0 + (float(income) * float(current) - offset) / denom
        new_factor = 1.0 + (float(income) * proposed - offset) / denom
        if old_factor <= factor_floor or new_factor <= factor_floor:
            skipped.append({"zone_no": z, "family": "WORK", "role": "ATT_SALARY", "reason": "SALARY_FACTOR_OUTSIDE_VALID_DOMAIN"})
            continue
        if abs(proposed - float(current)) > 1.0e-12:
            salary_candidates[z] = {
                "zone_no": z, "family": "WORK", "role": "ATT_SALARY", "branch": "DOMESTIC",
                "attr": salary_attr, "current": float(current), "proposed": proposed, "delta": proposed - float(current),
            }
            salary_log_effect[z] = math.log(new_factor / old_factor)
        else:
            salary_log_effect[z] = 0.0

    candidates: List[Dict[str, Any]] = []
    effect_rows: List[Dict[str, Any]] = []
    implemented_totals: Dict[str, Dict[str, float]] = defaultdict(lambda: {"estimated_prod_delta": 0.0, "estimated_att_delta": 0.0})
    max_effect_error = 0.0
    for row in normalized:
        z = row["zone_no"]; zr = zone_map[z]; attr = row["attr"]
        requested = float(row["requested_log_step"])
        salary_effect = salary_log_effect.get(z, 0.0) if (row["family"], row["role"], row["branch"]) == ("WORK", "ATT", "DOMESTIC") else 0.0
        attr_requested = requested - salary_effect
        # If salary design did not produce a candidate, the whole effect remains on ADD_ATT_W.
        if (row["family"], row["role"], row["branch"]) == ("WORK", "ATT", "DOMESTIC") and z in salary_residual:
            attr_requested = float(salary_residual[z])
        current = fval(zr.get(attr), None)
        if current is None:
            skipped.append(dict(row, reason="ATTRIBUTE_UNREADABLE")); continue
        low, high = (zahr_min, zahr_max) if row["branch"] == "ZAHR" else (attr_min, attr_max)
        preserve_zero = preserve_zero_zahr if row["branch"] == "ZAHR" else preserve_zero_domestic
        if float(current) <= EPS and preserve_zero:
            skipped.append(dict(row, reason="PRESERVE_ZERO_ATTRIBUTE", current=current)); continue
        if float(current) <= EPS:
            seed_floor = float(zcfg.get("seed_floor", 0.0)) if row["branch"] == "ZAHR" else float(cfg.get("add_seed_floor", 0.0))
            if seed_floor <= EPS:
                skipped.append(dict(row, reason="ZERO_ATTRIBUTE_WITHOUT_SEED_FLOOR", current=current)); continue
            base_value = seed_floor
            old_for_log = seed_floor
        else:
            base_value = float(current)
            old_for_log = float(current)
        proposed = clamp(base_value * math.exp(attr_requested), low, high)
        attr_actual = math.log(max(EPS, proposed) / max(EPS, old_for_log))
        total_actual = attr_actual + salary_effect
        error = total_actual - requested
        max_effect_error = max(max_effect_error, abs(error))
        if abs(proposed - float(current)) > 1.0e-12:
            candidates.append(dict(
                row, current=float(current), proposed=proposed,
                requested_attr_log_effect=attr_requested, actual_attr_log_effect=attr_actual,
                multiplier=(proposed / float(current) if abs(float(current)) > EPS else "SEEDED"),
            ))
        elif abs(salary_effect) <= 1.0e-12:
            skipped.append(dict(row, reason="CLAMPED_TO_NO_IMPLEMENTED_EFFECT", current=current))
            continue
        base_margin = max(0.0, float(row.get("base_margin_volume", 0.0) or 0.0))
        actual_delta = base_margin * math.expm1(total_actual)
        implemented_totals[row["family"]]["estimated_prod_delta" if row["role"] == "PROD" else "estimated_att_delta"] += actual_delta
        effect_rows.append({
            "zone_no": z, "family": row["family"], "role": row["role"], "branch": row["branch"],
            "requested_log_effect": requested, "actual_attribute_log_effect": attr_actual,
            "actual_salary_log_effect": salary_effect, "implemented_total_log_effect": total_actual,
            "effect_log_error": error, "base_margin_volume": base_margin,
            "implemented_margin_delta": actual_delta,
        })

    candidates.extend(salary_candidates[z] for z in sorted(salary_candidates))
    for row in implemented_totals.values():
        row["estimated_abs_gap"] = abs(row["estimated_prod_delta"] - row["estimated_att_delta"])
    attrs_changed = sorted(set(sval(r.get("attr")) for r in candidates))
    salary_summary = dict(salary_summary)
    salary_summary["candidate_count"] = len(salary_candidates)
    salary_summary["max_abs_effect_log_error"] = max_effect_error
    return {
        "candidate_rows": candidates, "skipped_rows": skipped, "effect_rows": effect_rows,
        "summary": {
            "candidate_count": len(candidates), "skipped_count": len(skipped),
            "attrs_changed": attrs_changed, "salary": salary_summary,
            "max_abs_effect_log_error": max_effect_error,
            "estimated_pa_delta_by_family": dict(implemented_totals),
            "backtracking_scale": scale, "scale_applied_once": True,
            "implemented_effect_row_count": len(effect_rows),
        },
    }


__all__ = [
    "COMPONENT_REGISTRY", "GENERATION_ATTRS", "build_td_signals", "design_td_candidates",
    "td_component_metrics", "design_generation_candidates", "sval", "fval", "ival", "clamp",
]
